@extends('layouts.app')
@section('title') Contato :: @parent @stop
@section('content')
    <div class="row">
        <div class="page-header">
            <h2>P&aacute;gina de Contato </h2>
        </div>
    </div>
@endsection