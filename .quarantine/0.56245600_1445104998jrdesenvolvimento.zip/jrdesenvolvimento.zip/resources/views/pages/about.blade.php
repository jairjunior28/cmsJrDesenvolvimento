@extends('layouts.app')
@section('title') About :: @parent @stop
@section('content')
    <div class="row">
        <div class="page-header">
            <h2>JR Desenvolvimento</h2>
            <p>Somos uma empresa de desenvolvimento de softwares, uma empresa que n&atilde;o segue regras pr&eacute;-estabelecidas.
                Criamos nossas pr&oacute;prias regras e padr&otilde;es, o que nos torna uma empresa inovadora e
                &uacute;nica  e.</p>
            <p> Desenvolvimento de sites e realiza&ccedil;&atilde;&otilde;es de otimiza&ccedil;&otilde;es (SEO) com novas t&eacute;cnicas de desenvolvimento
                &aacute;gil.
                Com esses e outros fatores &eacute; que faz da JR Desenvolvimento uma empresa de pouca idade mas cheia de metas, metas por tecnologia, cria&ccedil;&atilde;o e comunica&ccedil;&atilde;o.
                Nosso maior objetivo &eacute; avaliar e explorar tudo o que ainda n&atilde;o foi explorado, com o objetivo de tornar sua marca
                respeitada e conhecida no mercado como sin&ocirc;nimo de sucesso.</p><p>
                O que &eacute; desafio para muitas empresas atualmente!</p>
        </div>
    </div>
@endsection