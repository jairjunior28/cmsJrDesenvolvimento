<div id="footer">
    <div class="container">
        <p class="text-muted credit"><span style="text-align: left; float: left">&copy; 2015 <a href="#">

                </a></span> <span class="hidden-phone"
                                                    style="text-align: right; float: right">Desenvolvido por: <a
                        href="http://laravel.com/" alt="Laravel 5.1">Jair J&uacute;nior.</a></span></p>
    </div>
</div>