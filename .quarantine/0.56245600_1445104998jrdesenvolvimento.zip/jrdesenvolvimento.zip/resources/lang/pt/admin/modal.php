<?php

return [
    'create'        => 'Cadastrar',
    'edit'          => 'Editar',
    'reset'         => 'Limpar',
    'cancel'        => 'Cancelar',
    'general'       => 'Geral',
    'title'         => 'Título',
    'new'           => 'Novo',
    'delete'        => 'Remover',
    'items'         => 'Items',
    'delete_message'=> 'Tem certeza que quer remover este item?',
    'delete'        => 'Remover',

];