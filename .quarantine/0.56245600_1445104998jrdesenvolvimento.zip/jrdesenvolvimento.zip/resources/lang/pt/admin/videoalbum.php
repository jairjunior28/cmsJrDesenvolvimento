<?php

return [
    'videoalbum' => 'Video album',
    'numbers_of_items' =>'Number of items',
    'description' => 'Description',


];