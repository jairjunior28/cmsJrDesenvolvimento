<?php

return [
	'settings'         => 'Configurações',
	'homepage'         => 'Página inicial',
	'home'             => 'Home',
	'welcome'          => 'Bem vindo',
    'action'           => 'Ações',
    'back'             => 'Voltar',
    'created_at'       => 'Criado em',
    'language'         => 'Idioma',
    'yes'              => 'Sim',
    'no'               =>  'Não',
    'view_detail'      => 'Ver detalhes',
    'news_categories'  => 'Categorias de Notícias',
    'news_items'       => 'Notícias',
    'photo_albums'     => 'Álbuns de Fotos',
    'photo_items'      => 'Fotos',
    'video_albums'     => 'Álbuns de vídeos',
    'video_items'      => 'Vídeos',
    'users'            => 'Usuários',
	];