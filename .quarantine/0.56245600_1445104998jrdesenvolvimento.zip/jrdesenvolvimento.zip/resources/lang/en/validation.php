<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted'             => 'O :attribute deve ser acessado.',
    'active_url'           => 'O :attribute n&atilde;o &eacute; uma URL v&aacute;lida.',
    'after'                => 'O :attribute deve ser umaa data maior que :date.',
    'alpha'                => 'O :attribute deve conter somente letras.',
    'alpha_dash'           => 'O :attribute deve conter somente letras, n&uacute;meros, e tra&ccedil;os.',
    'alpha_num'            => 'O :attribute deve conter somente letras e n&uacute;meros.',
    'array'                => 'O :attribute deve ser um array.',
    'before'               => 'O :attribute deve ser uma data anterior &agrave; :date.',
    'between'              => [
        'numeric' => 'O :attribute deve ser entre :min e :max.',
        'file'    => 'O :attribute deve ser entre :min e :max kilobytes.',
        'string'  => 'O :attribute deve ser entre :min e :max characters.',
        'array'   => 'O :attribute deve ser entre :min e :max items.',
    ],
    'boolean'              => 'O :attribute campo deve ser verdadeiro ou falso.',
    'confirmed'            => 'O :attribute confirma&ccedil does not match.',
    'date'                 => 'O :attribute is not a valid date.',
    'date_format'          => 'O :attribute does not match the format :format.',
    'different'            => 'O :attribute e :other deve ser different.',
    'digits'               => 'O :attribute deve ser :digits digits.',
    'digits_between'       => 'O :attribute deve ser entre :min e :max digits.',
    'email'                => 'O :attribute deve ser a valid email address.',
    'exists'               => 'O selected :attribute is invalid.',
    'filled'               => 'O :attribute field is required.',
    'image'                => 'O :attribute deve ser an image.',
    'in'                   => 'O selected :attribute is invalid.',
    'integer'              => 'O :attribute deve ser an integer.',
    'ip'                   => 'O :attribute deve ser a valid IP address.',
    'max'                  => [
        'numeric' => 'O :attribute may not be greater than :max.',
        'file'    => 'O :attribute may not be greater than :max kilobytes.',
        'string'  => 'O :attribute may not be greater than :max characters.',
        'array'   => 'O :attribute may not have more than :max items.',
    ],
    'mimes'                => 'O :attribute deve ser a file of type: :values.',
    'min'                  => [
        'numeric' => 'O :attribute deve ser at least :min.',
        'file'    => 'O :attribute deve ser at least :min kilobytes.',
        'string'  => 'O :attribute deve ser at least :min characters.',
        'array'   => 'O :attribute must have at least :min items.',
    ],
    'not_in'               => 'O selected :attribute is invalid.',
    'numeric'              => 'O :attribute deve ser a number.',
    'regex'                => 'O :attribute format is invalid.',
    'required'             => 'O :attribute field is required.',
    'required_if'          => 'O :attribute field is required when :other is :value.',
    'required_with'        => 'O :attribute field is required when :values is present.',
    'required_with_all'    => 'O :attribute field is required when :values is present.',
    'required_without'     => 'O :attribute field is required when :values is not present.',
    'required_without_all' => 'O :attribute field is required when none of :values are present.',
    'same'                 => 'O :attribute e :other must match.',
    'size'                 => [
        'numeric' => 'O :attribute deve ser :size.',
        'file'    => 'O :attribute deve ser :size kilobytes.',
        'string'  => 'O :attribute deve ser :size characters.',
        'array'   => 'O :attribute must contain :size items.',
    ],
    'string'               => 'O :attribute deve ser a string.',
    'timezone'             => 'O :attribute deve ser a valid zone.',
    'unique'               => 'O :attribute has already been taken.',
    'url'                  => 'O :attribute format is invalid.',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'custom-message',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [],

];
