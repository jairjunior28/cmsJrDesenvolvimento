<?php

return [

    "title" => "T&iacute;tulo",
    'new' => "Novo",
    'created_at' => 'Criado em',
    'actions' => 'A&ccedi;&otilde;es',
    'edit' => 'Editar',
    'details' => 'Detalhes',
    'delete' => 'Apagar',
    'cancel' => 'Cancelar',
    'ok' => 'OK',
    "report" => "Reportar",
    'close' => 'Fechar',
    'back' => 'Voltar',
    'search' => 'Buscar',
    'start' => 'In&iacute;cio',
    'prev' => 'Anterior',
    'next' => 'Pr&oacute;ximo',
    'last' => '&Uacute;ltimo',
    'filter' => '(selecionado de um total de _MAX_ elements)',
    'view' => 'Mostrando 0 de 0 de um total of 0 elementos',
    'show' => 'Mostrando _START_ de _END_ de _TOTAL_ elementos',
    'noresult' => 'Nada foi encontrado aqui',
    'showmenu' => 'Mostrar _MENU_ elementos',
    'processing' => 'Processando ...',
    'sort' => 'organizando',
    'emptytable' => 'N&atilde;o dispon&iacute;vel na tabela de dados',

];
