<?php

return [
    'code' => 'C&oacute;digo',
    'icon' => 'Icone',
    'languages' => 'Linguagens',

];