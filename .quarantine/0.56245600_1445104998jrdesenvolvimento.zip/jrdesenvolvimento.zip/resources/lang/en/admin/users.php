<?php

return [
    'users' => 'Users',
    'name' =>   'Name',
    'username' =>   'Username',
    'email' =>   'Email',
    'password' =>  'Password',
    'password_confirmation' => 'Password confirmation',
    'activate_user' => 'Activate user',
    'active_user' => 'Active user',
    'yes' => 'Yes',
    'no' => 'No',
    'roles' => 'Roles',
    'roles_info' => 'Adding the role to user, be assigned all privileges for a given role.'

];
