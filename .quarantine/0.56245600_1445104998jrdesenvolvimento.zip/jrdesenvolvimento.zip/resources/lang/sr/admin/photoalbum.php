<?php

return [
    'photoalbum' => 'Фото албуми',
    'numbers_of_items' =>'Број слика',
    'description' => 'Опис',

];