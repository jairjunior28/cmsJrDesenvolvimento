<?php

return [
    'video' => 'Видео',
    'album' =>  'Албум',
    'album_cover' => 'Насловни видео',
    'slider' => 'Слајдер',
    'description' => 'Опис',
    'video' => 'Видео',
    'video_youtube' => 'Видео са youtube.com'

];