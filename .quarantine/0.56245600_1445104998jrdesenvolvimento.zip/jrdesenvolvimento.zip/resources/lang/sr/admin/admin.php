<?php

return [
	'settings' => 'Подешавања',
	'homepage' => 'Повратак на сајт ',
	'home' => 'Почетна',
    'welcome' => 'Добро дошли',
    'action' => 'Акције',
    'back' => 'Повратак',
    'created_at' => 'Креирано',
    'language' => 'Језик',
    'yes'       => 'Да',
    'no'        =>  'Не',
    'view_detail' => 'Детаљи',
    'news_categories' => 'Категорије новости',
    'news_items' => 'Новости',
    'photo_albums' => 'Фото албуми',
    'photo_items' => 'Фотографије',
    'video_albums' => 'Видео албуми',
    'video_items' => 'Видеои',
    'users' => 'Кориници',
	
	];