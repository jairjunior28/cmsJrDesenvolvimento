<?php

return [
    'photoalbum' => 'Foto albumi',
    'numbers_of_items' =>'Broj stavki',
    'description' => 'Opis',

];