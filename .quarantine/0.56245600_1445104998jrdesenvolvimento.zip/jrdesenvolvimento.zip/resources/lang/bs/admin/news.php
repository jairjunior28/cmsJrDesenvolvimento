<?php

return [
    'news' => 'Novosti',
    'introduction' => 'Uvodna',
    'content' => 'Cijela',
    'source' => 'Izvor',
    'picture' => 'Slika',
    'category' => 'Kategorija',

];