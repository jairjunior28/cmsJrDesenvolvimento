<?php

return [
    'roles' => 'Uloge',
    'adminrole' => 'Admin uloge',
    'userrole'  =>  'Korisničke uloge',
    'choose_role' =>   'Izaberite privilegije',
    'name'  => 'Naziv',

];